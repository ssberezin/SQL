﻿/******************************/
/****** Что это? **************/
/******************************/
  /*Триггер – это специализированная процедура, которая ав-
томатически вызывается SQL Server при возникновении
событий в базе данных. В SQL Server с версии SQL Server
2005 поддерживаются два типа триггеров:*/

/******************************/
/****** Типы тригеров *********/
/******************************/
/*DML-триггеры – выполняются при возникновении DML
событий: добавлении (INSERT), уда-
лении (DELETE) или обновлении (UPDATE) записей
таблиц или представлений.*/

/*DDL-триггеры – выполняются при возникновении
DDL (Data Definition Language – Язык Определения
Данных) событий: создание (CREATE), изменение
(ALTER) или удаление (DROP) объектов*/

/******************************/
/****** Замечания *********/
/******************************/
/*1. Если при объявлении триггера, указать единственное
ключевое слово FOR, то аргумент AFTER использу-
ется по умолчанию.
2. Нельзя создавать триггеры INSTEAD OF для моди-
фицированных представлений.
3. Триггеры AFTER используются только для таблиц.
4. Параметр WITH ENCRYPTION не может быть указан
для триггеров CLR.
5. Аргумент WITH APPEND установлен только для совме-
стимости с предыдущими версиями (на уровне 65). При
этом он может использоваться только при указании
параметра FOR без INSTEAD OF и не может указы-
ваться для триггеров CLR. В связи с тем, что в следующей
версии SQL Server аргумент WITH APPEND планируется полностью
исключить, его рекомендуется избегать.*/

/******************************/
/********** Правила ***********/
/******************************/
/*■■ НЕЛЬЗЯ создавать триггеры для временных таблиц,
но они могут обращаться к ним;
■■ НЕЛЬЗЯ создавать, изменять, удалять резервные
копии или восстанавливать из резервной копии
базы данных;
■■ триггеры могут использоваться для обеспечения
целостности данных, но их не следует использовать
вместо объявления целостности путем установле-
ния ограничения FOREIGN KEY;
■■ триггеры не могут возвращать результирующие на-
боры, поэтому при использовании оператора select
в теле триггера следует быть очень внимательным.
При этом во многих случаях, вместе с оператором
select используется директива IF EXISTS;
■■ поддерживаются рекурсивные AFTER триггеры,
при установке параметра базы данных RECURSIVE_
TRIGGERS в значение ON;
■■ можно создавать вложенные триггеры (поддер-
живается до 32 уровней вложенности), которые
фактически являются неявной рекурсией. Для
их поддержки необходимо установить параметр
NESTED TRIGGERS;
■■ в теле DML-триггера НЕЛЬЗЯ использовать опе-
раторы:
• все операции CREATE / ALTER / DROP;
• TRUNCATE TABLE;
• RECONFIGURE;
• LOAD DATABASE или TRANSACTION;
• GRANT и REVOKE;
• SELECT INTO;
• UPDATE STATISTICS.*/

/******************************/
/***** Как они работают? ******/
/******************************/
/*Работают они следующим образом:
■■ когда в базовую таблицу добавляются новые данные (новая
запись), то эти же данные добавляются сначала 
в базовую таблицу, а затем в таблицу inserted. Их
наличие в таблице inserted избавляет от необхо-
димости создавать специальные переменные для
доступа к этой информации.
■■ когда строка удаляется из таблицы, то она записывает-
ся в таблицу deleted, а затем удаляется из базовой
таблицы.
■■ когда строка обновляется, то старое значение записи за-
писывается в таблицу deleted и удаляется из базовой
таблицы, затем обновленная запись записывается
в базовую таблицу, а дальше в таблицу inserted.
То есть мы можем использовать таблицу DELETED
для получения значений записей, которые удаляются
из таблицы, а таблицу INSERTED для получения новых
записей перед их фактической вставкой.*/

/******************************/
/**** Несколько примеров ******/
/******************************/
--1
/*Тригер, который будет срабатывать
при каждой вставке данных в таблицу Categories и воз-
вращает сообщение о количестве измененных строк.*/
alter trigger addCategory on Categories for insert, update
as
raiserror('%d строк было добавлено или модифицировано
', 0, 1, @@rowcount)
return

insert into Categories values('myCategory', 'This is new Category', null);
go
--2
/*Триггер, который при добавлении новых данных о
поставщике, город которой London, бу-
дет выбрасывать сообщение об ошибке.*/
create trigger CheckCityTrigger on Suppliers for insert
as
begin
	--  получаем город поставщика, который добавляется
	declare @city varchar(25)
	select @city = City from inserted
	-- проверяем London ли это
	if (@city = 'London')
	begin 
		raiserror('В это городе сейчас эпидемия',0,1)
		rollback transaction
	end
	else
		print ('Данные добавлены успешно')
end
go

insert into Suppliers values('SomeCompany', null,null,null,'London',null,null,null,null,null,null); 
go
insert into Suppliers values('SomeCompany', null,null,null,'Paris',null,null,null,null,null,null); 
go

--3
/*Триггер, который при удалении Продукта категории
"Beverage" выдает сообщение об ошибке*/
alter trigger NotDeleteBevarege
on Products instead of delete
as
begin
declare @CategoryId int
-- get the identifier of 'Computer Science' theme
select @CategoryId = CategoryID
from Categories
where
CategoryName = 'Beverages'
-- check whether the identifier of removing book matches the
--@ThemeId
if exists (select * from deleted where CategoryID = @CategoryId)
	raiserror ('This Product cannot be deleted!',0,1)
end
go
delete from Products where ProductName = 'Microsoft SQL Server'
go 


/******************************/
/******* DDL - Тригеры ********/
/******************************/
/*после инструкции ON не-
обходимо указать область действия триггера:
■■ ALL SERVER – текущий сервер. Триггер будет сраба-
тывать при возникновении определенных собы-
тий в любом месте в рамках текущего сервера.
Например, CREATE_DATABASE, ALTER_LOGIN,
ALTER_INSTANCE и тому подобное.
■■ DATABASE – текущая база данных. Триггер будет сраба-
тывать при возникновении определенных событий
на уровне текущей базы данных или низших уровнях.
Например, CREATE_TABLE, DROP_DEFAULT,
ALTER_USER и тому подобное.*/

/******************************/
/******* запрет изменения и удаления таблиц ********/
/******************************/
create trigger NotAlterDropTable
on DATABASE /*ALL SERVER*/
for DROP_TABLE, ALTER_TABLE, CREATE_TABLE
as
begin
print 'Модификация и удаление таблиц запрещены.
Обратитесь к администратору.'
rollback
end
go

drop table a_p;

/******************************/
/******* Модифицировать триггер ********/
/******************************/
alter trigger NotAlterDropTable
on DATABASE
for DROP_TABLE, ALTER_TABLE, CREATE_TABLE
as
begin
print 'Модификация и удаление таблиц запрещены.
Обратитесь к администратору.'
rollback
end
go

create table fl(intdf varchar(24));

/******************************/
/******* Включить или выключить триггер ********/
/******************************/
disable trigger NotAlterDropTable on database;
enable trigger NotAlterDropTable on database;

/******************************/
/******* Удаление ********/
/******************************/
drop trigger NotAlterDropTable on database;

-- Включить все тригеры?
disable trigger All on all server
go

enable trigger NotAlterDropTable/*All*/ on database
go


-- Информация о тригерах?

-- информация о всех тригеррах в текущей  базе данных
select * from sys.triggers
go 

select * from sys.triggers
go 

-- тело тригера
select * from sys.sql_modules, sys.triggers
where sys.sql_modules.object_id = sys.triggers.object_id
go

select * from syscomments 
go

-- тригеры уровня сервера
select * from sys.server_triggers go
go

-- Ссылки foreng key?

ALTER TABLE Sales.TempSalesReason     
ADD CONSTRAINT FK_TempSales_SalesReason FOREIGN KEY (TempID)     
    REFERENCES Sales.SalesReason (SalesReasonID)
	on delete cascade on update cascade
;    
GO  


